    printf("%d\n",sum);
    return 0;
}
